package com.example.equipmentsstore;

public class Constant {

    public static final String TEST_URL1 = "http://test_bc_service.hescomtrm.com/TicketingService.asmx/";
    public static final String PROD_URL1 = "http://test_bc_service.hescomtrm.com/TicketingService.asmx/";
}
