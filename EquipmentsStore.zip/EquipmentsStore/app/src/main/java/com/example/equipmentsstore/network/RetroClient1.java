package com.example.equipmentsstore.network;

import com.example.equipmentsstore.network.RegisterApi;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.example.equipmentsstore.Constant.TEST_URL1;

public class RetroClient1 {
    private static String BASE_URL = TEST_URL1;

    public RetroClient1() {
            BASE_URL = TEST_URL1;
    }

    private static Retrofit getRetrofitInstance() {
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        return new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    public RegisterApi getApiService() {
        return getRetrofitInstance().create(RegisterApi.class);
    }

}
