package com.example.equipmentsstore.login;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class Loginviewmodel extends ViewModel {

    public MutableLiveData<String> name = new MutableLiveData<>();
    public MutableLiveData<String> Password = new MutableLiveData<>();
    private MutableLiveData<User> mutableLiveData;

    public MutableLiveData<User> getUser() {
        if (mutableLiveData == null) {
            mutableLiveData = new MutableLiveData<>();
        }
        return mutableLiveData;
    }
    public void onClick() {
        User employeeModel = new User(name.getValue(), Password.getValue());
        mutableLiveData.setValue(employeeModel);
    }
}
