package com.example.equipmentsstore.interfac;


import com.example.equipmentsstore.login.LoginDetails;

public interface ResponseInterface {

    public void responseSuccess(LoginDetails loginDetails);
    public void responseFailure();
}
