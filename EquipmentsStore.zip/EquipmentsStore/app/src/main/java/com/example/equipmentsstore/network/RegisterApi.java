package com.example.equipmentsstore.network;



import com.example.equipmentsstore.login.LoginDetails;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RegisterApi {

    @GET("Retrofit_loginDetails")
    Call<List<LoginDetails>>getlogin(@Query("username") String USERNAME, @Query("password") String PASSWORD);
}
