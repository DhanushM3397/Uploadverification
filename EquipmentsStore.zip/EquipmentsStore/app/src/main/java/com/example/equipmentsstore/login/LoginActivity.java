package com.example.equipmentsstore.login;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.equipmentsstore.MainActivity;
import com.example.equipmentsstore.R;
import com.example.equipmentsstore.network.RegisterApi;
import com.example.equipmentsstore.interfac.ResponseInterface;
import com.example.equipmentsstore.network.RetroClient1;
import com.example.equipmentsstore.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity implements ResponseInterface {
private Loginviewmodel loginmodel;
    private ActivityMainBinding binding;
    List<LoginDetails> loginlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        loginmodel = ViewModelProviders.of(this).get(Loginviewmodel.class);

        binding = DataBindingUtil.setContentView(LoginActivity.this, R.layout.activity_main);
        binding.setLifecycleOwner(this);
        binding.setLogin(loginmodel);

        loginlist = new ArrayList<>();


 loginmodel.getUser().observe(this, new Observer<User>() {
     @Override
     public void onChanged(User user) {
         if (TextUtils.isEmpty(Objects.requireNonNull(user).getUsername())) {
             binding.loginName.setError("Enter an username");
             binding.loginName.requestFocus();
             return;
         } else if (TextUtils.isEmpty(Objects.requireNonNull(user).getPassword())) {
             binding.loginPassword.setError("Enter a Password");
             binding.loginPassword.requestFocus();
             return;
         }

         loginDetails(user.getUsername(), user.getPassword(), LoginActivity.this);

     }


 });


}


    public void loginDetails(String USERNAME, String PASSWORD,ResponseInterface responseInterface) {
        RetroClient1 retroClient1 = new RetroClient1();
        RegisterApi api = retroClient1.getApiService();
        api.getlogin(USERNAME, PASSWORD).enqueue(new Callback<List<LoginDetails>>() {
            @Override
            public void onResponse(Call<List<LoginDetails>> call, Response<List<LoginDetails>> response) {
                if (response.isSuccessful()) {
                    loginlist = response.body();
                    responseInterface.responseSuccess(response.body().get(0));
                } else {
                    responseInterface.responseFailure();
                }

                }

            @Override
            public void onFailure(Call<List<LoginDetails>> call, Throwable t) {

                responseInterface.responseFailure();

            }
        });

    }


    @Override
    public void responseSuccess(LoginDetails loginDetails) {
        //Toast.makeText(this, "Login sucess", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    public void responseFailure() {
        Toast.makeText(this, "Login Failure", Toast.LENGTH_SHORT).show();

    }
}